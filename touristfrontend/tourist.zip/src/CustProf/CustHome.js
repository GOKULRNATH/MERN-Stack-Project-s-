import React from 'react'
import CustNav from './CustNav'
import Home from '../Components/Home'

function CustHome() {
  return (
    <div>
    <CustNav/>
    <Home/>
    </div>
  )
}

export default CustHome
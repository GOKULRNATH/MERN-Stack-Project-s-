import React from 'react'
import HotelNav from './HotelNav'
import Home from '../Home'


function RestHome() {
  return (
    <div>
    <HotelNav/>
    <Home/>
    </div>
  )
}

export default RestHome
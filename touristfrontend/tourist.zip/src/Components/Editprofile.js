import React from 'react'

function Editprofile() {
  return (
    <div>
        
    </div>
  )
}

export default Editprofile
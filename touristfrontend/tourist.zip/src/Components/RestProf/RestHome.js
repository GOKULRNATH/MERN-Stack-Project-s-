import React from 'react'
import RestNav from './RestNav'
import Home from '../Home'


function RestHome() {
  return (
    <div>
    <RestNav/>
    <Home/>
    </div>
  )
}

export default RestHome
import React from 'react'

function reportWebVitals() {
  return (
    <div>reportWebVitals</div>
  )
}

export default reportWebVitals
